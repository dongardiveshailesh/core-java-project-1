package Emailapp;

public class Emailapp {

	public static void main(String[] args) {
		email em1 = new email("Shailesh", "Dongardive");
		System.out.println(em1.ShowInfo());
	}
}
 