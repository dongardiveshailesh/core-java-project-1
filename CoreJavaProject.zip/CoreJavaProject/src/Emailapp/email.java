package Emailapp;

import java.util.Scanner;

public class email {

	private String firstName;
	private String lastName;
	private String password ;
	private String department;
	private int defaultPasswordLength = 9;
	private int mailboxCapacity = 500;
	private String alternateEmail;
	private String email;
	private String companySuffix = "tcs.com";

	//Constructor to receive the first name and last name
	public email(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;

		// Call the method asking for the department And return the Department
		this.department = setDepartment1();
		System.out.println("Department: " + this.department);

		// Call a method that return a random password
		this.password = randomPassword(defaultPasswordLength);
		System.out.println("Your Password is : "+ this.password);

		//Combine element to genarate email
		email= firstName.toLowerCase()+"."+lastName.toLowerCase()+"@"+department+companySuffix;
	}

	// Ask for the department
	private String  setDepartment1() {
		System.out.println("DEPARTMENTS CODE\n1 For Business Development\n2 For Software Developer\n3 For Software Tester\n4 For Full Stack Developer\n0 For None\n ENTER DEPARTMENT CODE: ");
		Scanner sc = new Scanner(System.in);
		int depChoice = sc.nextInt();
		if (depChoice==1) {return "Business Development";}
		if (depChoice==2) {return "Software Developer";}
		if (depChoice==3) {return "Software Tester";}
		if (depChoice==4) {return "Full Stack Developer";}
		else {return "";}	
	}
	// Generate a random password
	private String randomPassword(int length) {
		String passwordSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
		char[] password = new char[length]; 
		for(int i = 0;i<length;i++) {
			int rand = (int)(Math.random()*passwordSet.length());
			password[i] = passwordSet.charAt(rand);
		}
		return new String(password);
	}
	//Set the mailBox capacity
	public void setMailboxCapacity(int capacity) {
		this.mailboxCapacity = capacity;
	}

	//Set the alternate email
	public void setAlternetEmail(String alternateEmail ) {
		this.alternateEmail=alternateEmail;
	}
	
	public int getMailboxCapacity() {return mailboxCapacity;}
	public String getAlternetEmail() {return alternateEmail;}
	public String getPassword() {return password;}
	
	public String ShowInfo() {
		return "Display Name : "+firstName+lastName+"\nCompany Email : "+email+"\nMailbox Capacity : "+mailboxCapacity+"mb";
		
	}

}
